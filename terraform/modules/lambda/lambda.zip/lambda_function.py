import boto3
import pymysql
import os

def lambda_handler(event, context):
    # Read S3 bucket and object from event
    s3_event = event['Records'][0]['s3']
    bucket = s3_event['bucket']['name']
    key = s3_event['object']['key']

    # Download SQL file from S3
    s3 = boto3.client('s3')
    obj = s3.get_object(Bucket=bucket, Key=key)
    sql = obj['Body'].read().decode('utf-8')

    # Connect to MySQL
    conn = pymysql.connect(
        host=os.environ['DB_HOST'],
        user=os.environ['DB_USERNAME'],
        password=os.environ['DB_PASSWORD'],
        db=os.environ['DB_NAME']
    )


    with conn.cursor() as cursor:
        for stmt in sql.split(';'):
            if stmt.strip():
                cursor.execute(stmt)
        conn.commit()
    conn.close()
